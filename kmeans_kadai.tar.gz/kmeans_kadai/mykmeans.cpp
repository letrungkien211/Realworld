/**
 * @file mykmeans.cpp
 * @brief k-means
 *
 * @author Tatsuya Harada
 * @date Nov. 5, 2011
 */
#include "mykmeans.h"

/**
 * @brief k-means
 * 
 * @param mat Mat data matrix
 * @param nc the number of k of k-means
 * @param out_centmat Mat centroids (output)
 * @param out_idxmat Mat cluster index of mat (output)
 */
void MyKmeans(Mat& mat, int nc, Mat& out_centmat, Mat& out_idxmat)
{

}
