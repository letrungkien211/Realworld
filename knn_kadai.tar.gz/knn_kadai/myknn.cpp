/**
 * @file myknn.cpp
 * @brief k-nearest neighbor
 *
 * @author Tatsuya Harada
 * @date Nov. 5, 2011
 */

#include "myknn.h"

/**
 * @brief k-nearest neighbor
 * 
 * @param trainmat cv::Mat training data
 * @param trainidxmat cv::Mat labels of training data
 * @param testmat cv::Mat test data
 * @param residxmat cv::Mat estimated labels of test data (return value)
 * @param nk the number of k for KNN
 */
void MyKnn(Mat& trainmat, Mat& trainidxmat,
	   Mat& testmat, Mat& residxmat, int nk)
{

}
